
 # **Forensic Investigation on a USB Key** 




## Background
 On 2nd of March 2023, I acquired a USB key at Douglas College book shop at royal avenue New Westminster in order to use the USB to  save some codes done in a multimedia class. The USB contains 4 document from the multimedia class for summer semester. The USB name is Asolid USB-0114A with serial number 52363302 and has 32 gigabyte size. The USB is white in color and has  douglas name written on it writen with a black paint. The only item of evidence used for the analysis is a single USB key.  
 |Description|Serial number|Size|
 |--|--|--|
 |Asolid USB |52363302| 32GB|
 
 ![USB Details](img/USBImage-aol-05.jpg)
 ![USB Details](img/USBDetails-aol-05.png)


## Forensic Workstation
 The workstation used was a Thinkpad T480 5100 (20L6S7VS0X) with Intel(R) Core(TM) i5-8350U CPU @ 1.70GHz   1.90 GHz processor, 8GB of RAM. This system has a device id 0CEAB486-E276-4C53-BEC5-147DF08CA031, 00330-51496-86399-AAOEM product ID, 64bits operating system with Serial number PF1E0TDS. The CPU architecture is x86_64 and opeating mode with 32-bits and 64-bits. it has 39 bits physical address size and 48 bits virtual address size. The system contains an icon name computer-vm(Virtual Machine), with machine ID e32a2deb81e74944b89a3b080c5aa5b7. it also has a virtualization called oracle with Kali GNU/Linux rolling operating system. The kernel is linux 6.3.0-kali-amd64, arhitecture x86-64. The hardware vendor is innotek, Firmware model and version of VitualBox. The Firmware is 16years 9month 3weeks and 2days. The operating system allows us to acces the USB device without altering the evidence on the flash drive. before any action can be carried out the Window blocker of the CPU must be activated so as not to tamper with the evidence on the USB drive. This investiagtion should show that the USB is only a read only copy when mounting to the operating system for investigation. All report will be presented in a markdown file and screnshots.
 Additionally, the command interface line instruction will be used at the output in this report and information and command that was issued to and from.
 |Description|Model| Serial Number| Details|
 |--|--|--|--| 
 |Thinkpad| T480| 20L657V50X|8GB of Random Access Memory(RAM)|
 |Version of Linux| Kali GNU/Linux|6.3.0-kali-amd6| 64bits, Assigned 4GB of RAM and 30GB of Hard Disk|
 | 
 ![CPUdetails](Img/WorkstattionDetails-aol-05.png)
 ![CPUdetails](Img/CPUDetails-aol-05.png)
 ![OperatingSystem](Img/kali-aol-05.png)


## Setup and use of a software Write-blocker

 To set up a write blocker for digital forensit analysis, which is a device that allows investigators to examine media or preventing data rights occuring on the subject media which keeps data integrity intact when moving the data from a host machne to external storage device. Write-blocker can also be difine as a tool that prevent all the data media for been written to or modified. Hardware write-blocker is a device that we connect between the host machine and an externa storage device and essentially when you are transfering data or making an image of the host machine into an external device which will transfer the data in read-only mode which makes it impossible to alter the data. steps on how to enable write-blocking in the windows operating system using window registry.

 Open the run-command
 ![Runcommand](Img/runcommand-aol-05.png)
 Type regedit and click ok
 click on the HKEY_LOCAL_MACHINE
 ![Registry](Img/Registry-aol-05.png)
 click on system
 ![System](Img/SystemRegistry-aol-05.png)
 click on CurrentControlSet
 ![controlset](Img/ControlSet-aol-05.png)
 click on Control
 ![Control](Img/control-aol-05.png)
 the write-blocking that we want to work on does not exist and we need to create by right clicking on the control key and select new and key
  ![NewFolder](Img/NewKey-aol-05.png)
 ReName the folder StorageDevicePolicy and the folder will display as attached
 ![RenamingFolder](Img/StorageDeviceFolder-aol-05.png)
 ![Display of new Folder](Img/DefaultFolder-aol-05.png)
 You will need to create a new folder inside the newly created storage device folder and Rename as WriteProtect and right click to modify the file.
 ![New created folder](Img/NewKeyDefaultfolder-aol-05.png)
 ![Rename New created folder](Img/WriteProtect-aol-05.png)
 ![Modify New created folder](Img/Modify-aol-05.png)
 Change the value data from 0 to 1 and press ok.
 ![Value data ](Img/Hexadecimal-aol-05.png)
 After all the above step has been completed, then the USB which is the evident can be inserted.

 ## Media Backup and creation of forensic copy
 To make a forensic copy of the an FTK software will assist in accheving the forensic Image as listed below:
 Download ftk software from the internet and install the software
  ![Download FTK and Install](Img/ftkImager-aol-05.png)
 Open FTK Imager and launch FTK Imager on your forensic workstation which is your computer
  ![Lauch FTK](Img/Modify-aol-05.png)
 Select the "File" Menu menu located in the top left corner of the FTK Imager interface and
 choose "Create Disk Image":
 ![Creation of Forensic Image](Img/CreatingImage-aol-05.png)
 Select the Source Drive: which is the physical drive as the only hard disk without partition, the other driv which is the logical drive is used for drive with partition which means leads us to the best option of physical drive.
 ![Drive Selection](Img/physicalharddisk-aol-05.png)
 Additionally to the create hard drive, you will see a list of available drives and devices in the "Select Device" field.
 Locate and select the USB drive from the list. It should be listed by its device name or drive and  click finish.
 ![Select Drive](Img/ftkUSBslection.aol-05%20.png)
 The above step will lead to adding the location were you want to create the Image
 ![Forensic Image Location](Img/AddftkLocation-aol-05.png)
 Depending on the specified requirements, you can configure additional options in the "Create Disk Image" window. These options may include choosing the destination for the forensic copy, selecting the image format (e.g., E01, DD, or RAW), and specifying any compression or encryption settings.Ensure that you choose options that align with the forensic imaging needs.
 ![Forensic Image Type](Img/FTKImagetype-aol-05.png)
 Start the Imaging Process:
 Once you have selected the source drive and configured any additional options, click the "Start" button to begin the imaging process.
 ![Evidence information](Img/Evidenceinfo-aol-05.png)
 ![Evidence information](Img/ForensicCopy-aol-05.png)
 ![Evidence information](Img/Imaging-aol-05.png)
 Then you click on start
 Monitor the Progress:
 FTK Imager will start creating the forensic image from the selected USB drive. You can monitor the progress in the status bar or window that appears during the imaging process. wnen the process is complete it is advisable to verify the integrity of the Image to show that it matches the source.
 ![Evidence information](Img/ImageVerification-aol-05.png)
 Verify the Integrity 
 ![Evidence information](Img/ImageCompletion-aol-05.png)
 After the imaging process is complete, you can use FTK Imager or other tools to verify the integrity of the forensic copy to ensure it matches the source drive.
 Document the Process, the source drive has now been imaged and documented. 


 ## Chain of Custody
  Case Number:  Case1-aol-05                          
  
  Offence: Stelen confidential file         

  Submitting Officer: Adenike Oloyede 300373205 

  Suspect: Austin Brown

  Victeem : Rahim Virani

  Location of Seizure: Douglas College New Westminster Campus

  Date/Time Seized: Sept 27, 2323  

  |Item|Item Name|Model number|Quantity|Item Desciption|
  |--|--|--|--|--|
  |USB Key| Asolid| 0114A| 1| A white 32GB of the evidence|
  |USB Key| Lexar| |1| A black lexar of 256GB was used for the Forensic Imaging of the Evidence|

  ###This evidence was received Imaged and handed over

  |Case number| Evidence Submitted By| Evidence Received By| Date Submitted| 
  |--|--|--|--|
  |Case1-aol-05| Adenike Oloyede| Adenike Oloyede| 27th September, 2023 |


 ## APA Citation
 Author(s): Bruce Nikkil.
 Publication Year: 2016
 Title of Book: Forensic Imaging
 Publisher: William Pollock
 

