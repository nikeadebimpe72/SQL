﻿using static System.Console;

//AdenikeO_300373205_CSIS1175(003)

namespace Lab1_Adenike
{
    internal class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Calculate your tax");


            float Tax = 0;
            float Income;
            string status;
            float IncomeAfterTax;


            WriteLine("Enter for Status Single or Married");
            status = ReadLine();
            WriteLine("Enter your Income");
            Income = float.Parse(ReadLine());

             if (Income <= 0)
            {
                WriteLine("Error: Enter a valid income");
            }

            // "Equals" method is used to compare two values for equality
            // evaluating the value stored in the "status" variable is equal to the string "Single"

            if (status.Equals("Single"))
            {
                // Calculate tax based on the income
                if (Income <= 8000)
                {
                    Tax = Income * (float)0.1;//10% tax rate
                }
                else if (Income > 8000 && Income <= 32000)
                {
                    //15% tax rate
                    Tax = 800 + (0.15f * (Income - 8000));
                }
                else if (Income > 32000)
                {
                    Tax = 440 * ((25 / 100) * Income); //25% tax rate
                }
                else
                {
                    WriteLine("Enter the single income");
                }

            }
            else if (status.Equals("Married"))
            {
                // Calculate tax based on the income
                if (Income <= 16000)
                {
                    Tax = Income * (float)0.1;//10% tax rate

                }
                else if (Income > 16000 && Income <= 64000)
                {
                    //15% tax rate
                    Tax = (1600 + (0.15f * (Income - 16000)));

                }
                else if (Income > 64000)
                {
                    Tax = 440 * ((0.25f) * (Income - 64000));
                }
                else
                {
                    WriteLine("Enter valid Income");
                }
            }
            else
            {
                WriteLine("Enter your marital status");
                return;
            }


            // calculate income after tax

            IncomeAfterTax = Income - Tax;

            // the output display 

            WriteLine("Enter your total income before tax: {0:F2}", Income);
            WriteLine("Enter your total tax: {0:F2}", Tax);
            WriteLine("calculate Income after tax: {0:F2}", IncomeAfterTax);

        }
    }
}
